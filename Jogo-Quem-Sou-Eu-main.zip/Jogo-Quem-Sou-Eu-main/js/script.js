const listPersonagens = [
 (personagem001 = {
    nome: "ABACATE",
    imagem:"./img/ABABATE.jpg",
  }),
 (personagem002 = {
    nome: "ABACAXI",
    imagem:"./img/ABACAXI.jpg",
  }),
 (personagem003 = {
    nome: "ABELHA",
    imagem:"./img/ABELHA.jpg",
  }),
 (personagem004 = {
    nome: "ABÓBORA",
    imagem:"./img/ABOBORA.jpg",
  }),
  (personagem005 = {
    nome: "ARANHA",
    imagem:"./img/ARANHA.jpg",
  }),
 (personagem006 = {
    nome: "ARARA",
    imagem:"./img/ARARA.jpg",
  }),
 (personagem007 = {
    nome: "ARMÁRIO",
    imagem:"./img/ARMARIO.jpg",
  }),
 (personagem008 = {
    nome: "ÁRVORE",
    imagem:"./img/ARVORE.jpg",
  }),
  (personagem009 = {
    nome: "ASTRONAUTA",
    imagem:"./img/ASTRONAUTA.jpg",
  }),
 (personagem010 = {
    nome: "AVIÃO",
    imagem:"./img/AVIAO.jpg",
  }),
 (personagem011 = {
    nome: "AZEITONA",
    imagem:"./img/AZEITONA.jpg",
  }),
 (personagem012 = {
    nome: "BAILARINA",
    imagem:"./img/BAILARINA.jpg",
  }),
 (personagem013 = {
    nome: "BALA",
    imagem:"./img/BALA.jpg",
  }),
 (personagem014 = {
    nome: "BALANÇO",
    imagem:"./img/BALANCO.jpg",
  }),
 (personagem015 = {
    nome: "BALÃO",
    imagem:"./img/BALAO.jpg",
  }),
 (personagem016 = {
    nome: "BALDE",
    imagem:"./img/BALDE.jpg",
  }),
 (personagem017 = {
    nome: "BALEIA",
    imagem:"./img/BALEIA.jpg",
  }),
 (personagem018 = {
    nome: "BAMBOLÊ",
    imagem:"./img/BAMBOLE.jpg",
  }),
 (personagem019 = {
    nome: "BANANA",
    imagem:"./img/BANANA.jpg",
  }),
  (personagem020 = {
    nome: "BANCO",
    imagem:"./img/BANCO.jpg",
  }),
  (personagem021 = {
    nome: "BARATA",
    imagem:"./img/BARBEIRO.jpg",
  }),
  (personagem022 = {
    nome: "BARBEIRO",
    imagem:"./img/BARBEIRO.jpg",
  }),
  (personagem023 = {
    nome: "BARCO",
    imagem:"./img/BARCO.jpg",
  }),
  (personagem024 = {
    nome:"BARRACA",
    imagem: "./img/BARRACA.jpg",
  }),
  (personagem025 = {
    nome: "BARRIL",
    imagem:"./img/BARRIL.jpg",
  }),
  (personagem026 = {
    nome: "BASQUETE",
    imagem:"./img/BASQUETE.jpg",
  }),
 (personagem027 = {
    nome: "BATATA",
    imagem:"./img/BATATA.jpg",
  }),
 (personagem028 = {
    nome: "BATEDEIRA",
    imagem:"./img/BATEDEIRA.jpg",
  }),
 (personagem029 = {
    nome: "BATERIA",
    imagem:"./img/BATERIA.jpg",
  }),
 (personagem030 = {
    nome: "BEBÊ",
    imagem:"./img/BEBÊ.jpg",
  }),
  (personagem031 = {
    nome: "BELICHE",
    imagem:"./img/BELICHE.jpg",
  }),
 (personagem032 = {
    nome: "BERINJELA",
    imagem:"./img/BERINJELA.jpg",
  }),
 (personagem033 = {
    nome: "BERMUDA",
    imagem:"./img/BERMUDA.jpg",
  }),
 (personagem034 = {
    nome: "BESOURA",
    imagem:"./img/BESOURO.jpg",
  }),
  (personagem035 = {
    nome: "BETERRABA",
    imagem:"./img/BETERRABA.jpg",
  }),
 (personagem036 = {
    nome: "BEXIGAS",
    imagem:"./img/BEXIGAS.jpg",
  }),
  (personagem037 = {
    nome: "BIBLIOTECA",
    imagem:"./img/BIBLIOTECA.jpg",
  }),
  (personagem038 = {
    nome: "BICICLETA",
    imagem: "./img/BICICLETA.jpg",
  }),
 (personagem039 = {
    nome: "BIFE",
    imagem:"./img/BIFE.jpg",
  }),
 (personagem040 = {
    nome: "BINÓCULO",
    imagem:"./img/BINOCULO.jpg",
  }),
  (personagem041 = {
    nome: "BIQUINI",
    imagem: "./img/BIQUINI.jpg",
  }),
 (personagem042 = {
    nome: "BISCOITO",
    imagem:"./img/BISCOITO.jpg",
  }),
 (personagem043 = {
    nome: "BOBO",
    imagem:"./img/BOBO.jpg",
  }),
 (personagem044 = {
    nome: "BOCA",
    imagem:"./img/BOCA.jpg",
  }),
 (personagem045 = {
    nome: "BOLA",
    imagem:"./img/BOLA.jpg",
  }),
  (personagem046 = {
    nome: "BOLACHA",
    imagem: "./img/BOLACHA.jpg",
  }),
  (personagem047 = {
    nome:"BOLICHE",
    imagem:"./img/BOLICHE.jpg",
  }),
 (personagem048 = {
    nome: "BOLO",
    imagem:"./img/BOLO.jpg",
  }),
 (personagem049 = {
    nome: "BOLSA",
    imagem:"./img/BOLSA.jpg",
  }),
 (personagem050 = {
    nome: "BOMBA",
    imagem:"./img/BOMBA.jpg",
  }),
  (personagem051 = {
    nome: "BOMBEIRO",
    imagem:"./img/BOMBEIRO.jpg",
  }),
 (personagem052 = {
    nome: "BONECA",
    imagem:"./img/BONECA.jpg",
  }),
 (personagem053 = {
    nome: "BORBOLETA",
    imagem:"./img/BORBOLETA.jpg",
  }),
  personagem054 = {
    nome: "BORRACHA",
    imagem:"./img/BORRACHA.jpg",
  },
 (personagem055 = {
    nome: "BOTA",
    imagem:"./img/BOTA.jpg",
  }),
 (personagem056 = {
    nome: "BOTÃO",
    imagem:"./img/BOTAO.jpg",
  }),
 (personagem057 = {
    nome: "BOXE",
    imagem:"./img/BOXE.jpg",
  }),
 (personagem058 = {
    nome: "BUDA",
    imagem:"./img/BUDA.jpg",
  }),
 (personagem059 = {
    nome: "BULE",
    imagem:"./img/BULE.jpg",
  }),
  (personagem060 = {
    nome: "BUMERANGUE",
    imagem:"./img/BUMERANGUE.jpg",
  }),
  (personagem061 = {
    nome: "BUQUÊ",
    imagem: "./img/BUQUE.jpg",
  }),
  (personagem062 = {
    nome:"BURRO",
    imagem:"./img/BURRO.jpg",
  }),
  (personagem063 = {
    nome: "BUSSULA",
    imagem: "./img/BUSSULA.jpg",
  }),
 (personagem064 = {
    nome: "CABANA",
    imagem:"./img/CABANA.jpg",
  }),
  (personagem065 = {
    nome: "CABRITO",
    imagem: "./img/CABRITO.jpg",
  }),
  (personagem066 = {
    nome: "CACHOEIRA",
    imagem: "./img/CACHOEIRA.jpg",
  }),
  (personagem065 = {
    nome: "CACHORRO",
    imagem: "./img/CACHORRO.jpg",
  }),
 (personagem066 = {
    nome: "CADEIRA",
    imagem:"./img/CADEIRA.jpg",
  }),
 (personagem067 = {
    nome: "CADERNO",
    imagem:"./img/CADERNO.jpg",
  }),
 (personagem068 = {
    nome: "CALÇA",
    imagem:"./img/CALCA.jpg",
  }),
 (personagem069 = {
    nome: "CALOR",
    imagem:"./img/CALOR.jpg",
  }),
 (personagem070 = {
    nome: "CAMA",
    imagem:"./img/CAMA.jpg",
  }),
 (personagem071 = {
    nome: "CAMALEÃO",
    imagem:"./img/CAMALEAO.jpg",
  }),
 (personagem072 = {
    nome: "CAMARÃO",
    imagem:"./img/CAMARAO.jpg",
  }),
  (personagem073 = {
    nome:"CAMINHÃO",
    imagem:"./img/CAMINHAO.jpg",
  }),
 (personagem074 = {
    nome: "CAMISETA",
    imagem:"./img/CAMISETA.jpg",
  }),
 (personagem075 = {
    nome: "CANGURU",
    imagem:"./img/CANGURU.jpg",
  }),
  (personagem076 = {
    nome: "CANHÃO",
    imagem:"./img/CANHAO.jpg",
  }),
 (personagem077 = {
    nome: "CANOA",
    imagem:"./img/CANOA.jpg",
  }),
 (personagem078 = {
    nome: "CARAMUJO",
    imagem:"./img/CARAMUJO.jpg",
  }),
  (personagem079 = {
    nome:"CARANGUEJO",
    imagem:"./img/CARANGUEJO.jpg",
  }),
  (personagem080 = {
    nome: "CARNEIROO",
    imagem:"./img/CARNEIRO.jpg",
  }),
  (personagem081 = {
    nome: "CARROSSEL",
    imagem: "./img/CARROSSEL.jpg",
  }),
 (personagem082 = {
    nome: "CASA",
    imagem:"./img/CASA.jpg",
  }),
 (personagem083 = {
    nome: "CASACO",
    imagem:"./img/CASACO.jpg",
  }),
 (personagem084 = {
    nome: "CASTELO",
    imagem:"./img/CASTELO.jpg",
  }),
 (personagem085 = {
    nome: "CATAVENTO",
    imagem:"./img/CATAVENTO.jpg",
  }),
 (personagem086 = {
    nome: "CAVALO",
    imagem:"./img/CAVALO.jpg",
  }),
 (personagem087 = {
    nome: "CEBOLA",
    imagem:"./img/CEBOLA.jpg",
  }),
  (personagem088 = {
    nome: "CEGONHA",
    imagem: "./img/CEGONHA.jpg",
  }),
 (personagem089 = {
    nome: "CENOURA",
    imagem:"./img/CENOURA.jpg",
  }),
 (personagem090 = {
    nome: "CENTOPEIA",
    imagem:"./img/CENTOPEIA.jpg",
  }),
 (personagem091 = {
    nome: "CERCA",
    imagem:"./img/CERCA.jpg",
  }),
 (personagem092 = {
    nome: "CEREAL",
    imagem:"./img/CEREAL.jpg",
  }),
 (personagem093 = {
    nome: "CEREJAS",
    imagem:"./img/CEREJAS.jpg",
  }),
 (personagem094 = {
    nome: "CESTA",
    imagem:"./img/CESTA.jpg",
  }),
  (personagem095 = {
    nome: "CIGANA",
    imagem:"./img/CIGANA.jpg",
  }),
 (personagem096 = {
    nome: "CIRCO",
    imagem:"./img/CIRCO.jpg",
  }),
 (personagem097 = {
    nome: "COBRA",
    imagem:"./img/COBRA.jpg",
  }),
 (personagem098 = {
    nome: "COCA",
    imagem:"./img/COCA.jpg",
  }),
 (personagem099 = {
    nome: "COCO",
    imagem:"./img/COCO.jpg",
  }),
  (personagem100 = {
    nome:"COELHO",
    imagem:"./img/COELHO.jpg",
  }),
 (personagem101 = {
    nome:"COGUMELOS",
    imagem:"./img/COGUMELOS.jpg",
  }),
 (personagem102 = {
    nome:"COLAR",
    imagem:"./img/COLAR.jpg",
  }),
 (personagem103 = {
    nome:"COLMEIA",
    imagem:"./img/COLMEIA.jpg",
  }),
 (personagem104 = {
    nome:"CONFEITEIRO",
    imagem:"./img/CONFEITEIRO.jpg",
  }),
 (personagem105 = {
    nome:"CORAÇÃO",
    imagem:"./img/CORACAO.jpg",
  }),
 (personagem106 = {
    nome:"CORDEIRO",
    imagem:"./img/CORDEIRO.jpg",
  }),
 (personagem107 = {
    nome:"COROA",
    imagem:"./img/COROA.jpg",
  }),
 (personagem108 = {
    nome:"CORTINA",
    imagem:"./img/CORTINA.jpg",
  }),
 (personagem109 = {
    nome:"CORUJA",
    imagem:"./img/CORUJA.jpg",
  }),
 (personagem110 = {
    nome:"COUVE-FLOR",
    imagem:"./img/COUVEFLOR.jpg",
  }),
  (personagem111 = {
    nome: "COZINHA",
    imagem:"./img/COZINHA.jpg",
  }),
 (personagem112 = {
    nome:"CUBO",
    imagem:"./img/CUBO.jpg",
  }),
 (personagem113 = {
    nome:"CUPIDO",
    imagem:"./img/CUPIDO.jpg",
  }),
  (personagem114 = {
    nome: "EGITO",
    imagem:"./img/EGITO.jpg",
  }),
  (personagem115 = {
    nome:"ELEFANTE",
    imagem:"./img/ELEFANTE.jpg",
  }),
  (personagem116 = {
    nome: "ESCADA",
    imagem: "./img/ESCADA.jpg",
  }),
  (personagem117 = {
    nome: "ESCORREGADOR",
    imagem: "./img/ESCORREGADOR.jpg",
  }),
  (personagem118 = {
    nome: "ESCOVA",
    imagem: "./img/ESCOVA.jpg",
  }),
  (personagem119 = {
    nome: "ESPAÇO",
    imagem:"./img/ESPACO.jpg",
  }),
  (personagem120 = {
    nome: "ESPADA",
    imagem: "./img/ESPADA.jpg",
  }),
  (personagem121 = {
    nome: "ESTRADA",
    imagem: "./img/ESTRADA.jpg",
  }),
  (personagem122 = {
    nome: "FÁBRICA",
    imagem:"./img/FABRICA.jpg",
  }),
  (personagem123 = {
    nome: "FÁBULAS",
    imagem: "./img/FABULAS.jpg",
  }),
  (personagem124 = {
    nome:"FACA",
    imagem: "./img/FACA.jpg",
  }),
  (personagem125 = {
    nome: "FADA",
    imagem: "./img/FADA.jpg",
  }),
 (personagem126 = {
    nome: "FAMÍLIA",
    imagem: "./img/FADA.jpg",
  }),
 (personagem127 = {
    nome: "FANTASIA",
    imagem: "./img/FANTASIA.jpg",
  }),
 (personagem128 = {
    nome: "FANTASMA",
    imagem: "./img/FANTASMA.jpg",
  }),
 (personagem129 = {
    nome: "FARAÓ",
    imagem: "./img/FARAO.jpg",
  }),
 (personagem130 = {
    nome: "FARINHA",
    imagem: "./img/FARINHA.jpg",
  }),
 (personagem131 = {
    nome: "FARAOESTE",
    imagem: "./img/FAROESTE.jpg",
  }),
 (personagem132 = {
    nome: "FAROFA",
    imagem: "./img/FAROFA.jpg",
  }),
 (personagem133 = {
    nome: "FAROL",
    imagem: "./img/FAROL.jpg",
  }),
 (personagem134 = {
    nome: "FAXINA",
    imagem: "./img/FAXINA.jpg",
  }),
 (personagem135 = {
    nome: "FAZENDA",
    imagem: "./img/FAZENDA.jpg",
  }),
 (personagem136 = {
    nome: "FEIJÃO",
    imagem: "./img/FEIJAO.jpg",
  }),
 (personagem137 = {
    nome: "FEIRANTE",
    imagem: "./img/FEIRANTE.jpg",
  }),
 (personagem138 = {
    nome: "FELICIDADE",
    imagem: "./img/FELICIDADE.jpg",
  }),
 (personagem139 = {
    nome: "FELINOS",
    imagem: "./img/FELINOS.jpg",
  }),
 (personagem140 = {
    nome: "FENO",
    imagem: "./img/FENO.jpg",
  }),
 (personagem141 = {
    nome: "FÉRIAS",
    imagem: "./img/FERIAS.jpg",
  }),
 (personagem142 = {
    nome: "FERIMENTO",
    imagem: "./img/FERIMENTO.jpg",
  }),
 (personagem143 = {
    nome: "FERRADURA",
    imagem: "./img/FERRADURA.jpg",
  }),
 (personagem144 = {
    nome: "FERRARI",
    imagem: "./img/FERRARI.jpg",
  }),
 (personagem145 = {
    nome: "FESTA",
    imagem: "./img/FESTA.jpg",
  }),
 (personagem146 = {
    nome: "FIGO",
    imagem: "./img/FIGO.jpg",
  }),
 (personagem147 = {
    nome: "FILA",
    imagem: "./img/FILA.jpg",
  }),
 (personagem148 = {
    nome: "FILHOTE",
    imagem: "./img/FILHOTE.jpg",
  }),
 (personagem149 = {
    nome: "FIVELA",
    imagem: "./img/FIVELA.jpg",
  }),
 (personagem150 = {
    nome: "FOCA",
    imagem: "./img/FOCA.jpg",
  }),
 (personagem151 = {
    nome: "FOFOCA",
    imagem: "./img/FOFOCA.jpg",
  }),
 (personagem152 = {
    nome: "FOGÃO",
    imagem: "./img/FOGAO.jpg",
  }),
 (personagem153 = {
    nome: "FOGUEIRA",
    imagem: "./img/FOGUEIRA.jpg",
  }),
 (personagem154 = {
    nome: "FOGUETE",
    imagem: "./img/FOGUETE.jpg",
  }),
 (personagem155 = {
    nome: "FOLHA",
    imagem: "./img/FOLHA.jpg",
  }),
 (personagem156 = {
    nome: "FONE",
    imagem: "./img/FONE.jpg",
  }),
 (personagem157 = {
    nome: "FORMATURA",
    imagem: "./img/FORMATURA.jpg",
  }),
 (personagem158 = {
    nome: "FORMIGA",
    imagem: "./img/FORMIGA.jpg",
  }),
 (personagem159 = {
    nome: "FORNO",
    imagem: "./img/FORNO.jpg",
  }),
 (personagem160 = {
    nome: "FORTE",
    imagem: "./img/FORTE.jpg",
  }),
 (personagem161 = {
    nome: "FORTUNA",
    imagem: "./img/FORTUNA.jpg",
  }),
 (personagem162 = {
    nome: "FÓSFOROS",
    imagem: "./img/FOSFOROS.jpg",
  }),
 (personagem163 = {
    nome: "FOTO",
    imagem: "./img/FOTO.jpg",
  }),
 (personagem164 = {
    nome: "FUMAÇA",
    imagem: "./img/FUMACA.jpg",
  }),
 (personagem165 = {
    nome: "FUSCA",
    imagem: "./img/FUSCA.jpg",
  }),
 (personagem166 = {
    nome: "FUTEBOL",
    imagem: "./img/FUTEBOL.jpg",
  }),
 (personagem167 = {
    nome: "GAFANHOTO",
    imagem: "./img/GAFANHOTO.jpg",
  }),
 (personagem168 = {
    nome: "GAIOLA",
    imagem: "./img/GAIOLA.jpg",
  }),
 (personagem169 = {
    nome: "GALHO",
    imagem: "./img/GALHO.jpg",
  }),
 (personagem170 = {
    nome: "GALINHA",
    imagem: "./img/GALINHA.jpg",
  }),
 (personagem171 = {
    nome: "GALO",
    imagem: "./img/GALO.jpg",
  }),
 (personagem172 = {
    nome: "GALOCHA",
    imagem: "./img/GALOCHA.jpg",
  }),
 (personagem173 = {
    nome: "GAMBÁ",
    imagem: "./img/GAMBA.jpg",
  }),
 (personagem174 = {
    nome: "GANGORRA",
    imagem: "./img/GANGORRA.jpg",
  }),
 (personagem175 = {
    nome: "GANSO",
    imagem: "./img/GANSO.jpg",
  }),
 (personagem176 = {
    nome: "GARAGEM",
    imagem: "./img/GARAGEM.jpg",
  }),
 (personagem177 = {
    nome: "GARÇA",
    imagem: "./img/GARCA.jpg",
  }),
 (personagem178 = {
    nome: "GARÇONETE",
    imagem: "./img/GARCONETE.jpg",
  }),
 (personagem179 = {
    nome: "GARFO",
    imagem: "./img/GARFO.jpg",
  }),
 (personagem180 = {
    nome: "GAROTA",
    imagem: "./img/GAROTA.jpg",
  }),
 (personagem181 = {
    nome: "GAROTO",
    imagem: "./img/GAROTO.jpg",
  }),
 (personagem182 = {
    nome: "GARRAFA",
    imagem: "./img/GARRAFA.jpg",
  }),
 (personagem183 = {
    nome: "GATO",
    imagem: "./img/GATO.jpg",
  }),
 (personagem184 = {
    nome: "GAVETAS",
    imagem: "./img/GAVETAS.jpg",
  }),
 (personagem185 = {
    nome: "GAVIÃO",
    imagem: "./img/GAVIAO.jpg",
  }),
 (personagem186 = {
    nome: "GELADEIRA",
    imagem: "./img/GELADEIRA.jpg",
  }),
 (personagem187 = {
    nome: "GELATINA",
    imagem: "./img/GELATINA.jpg",
  }),
 (personagem188 = {
    nome: "GELÉIA",
    imagem: "./img/GELEIA.jpg",
  }),
 (personagem189 = {
    nome: "GELO",
    imagem: "./img/GELO.jpg",
  }),
 (personagem190 = {
    nome: "GEMA",
    imagem: "./img/GEMA.jpg",
  }),
 (personagem191 = {
    nome: "GEMÊAS",
    imagem: "./img/GEMÊAS.jpg",
  }),
 (personagem192 = {
    nome: "GEMÊAS",
    imagem: "./img/GEMÊAS.jpg",
  }),
 (personagem193 = {
    nome: "GÊNIO",
    imagem: "./img/GENIO.jpg",
  }),
 (personagem194 = {
    nome: "GIGANTE",
    imagem: "./img/GIGANTE.jpg",
  }),
 (personagem195 = {
    nome: "GINÁSTICA",
    imagem: "./img/GINASTICA.jpg",
  }),
 (personagem196 = {
    nome: "GINCANA",
    imagem: "./img/GINCANA.jpg",
  }),
 (personagem197 = {
    nome: "GIRAFA",
    imagem: "./img/GIRAFA.jpg",
  }),
 (personagem198 = {
    nome: "GIRASSOL",
    imagem: "./img/GIRASSOL.jpg",
  }),
 (personagem199 = {
    nome: "GIZ",
    imagem: "./img/GIZ.jpg",
  }),
 (personagem200 = {
    nome: "GOIABA",
    imagem: "./img/GOIABA.jpg",
  }),
 (personagem201 = {
    nome: "GOLEIRO",
    imagem: "./img/GOLEIRO.jpg",
  }),
 (personagem202 = {
    nome: "GOLFE",
    imagem: "./img/GOLFE.jpg",
  }),
 (personagem203 = {
    nome: "GOLFINHOS",
    imagem: "./img/GOLFINHOS.jpg",
  }),
 (personagem204 = {
    nome: "GOMA",
    imagem: "./img/GOMA.jpg",
  }),
 (personagem205 = {
    nome: "GORILA",
    imagem: "./img/GORILA.jpg",
  }),
 (personagem206 = {
    nome: "GOTA",
    imagem: "./img/GOTA.jpg",
  }),
 (personagem207 = {
    nome: "GULOSEIMAS",
    imagem: "./img/GULOSEIMAS.jpg",
  }),
 (personagem208 = {
    nome: "HABILIDADE",
    imagem: "./img/HABILIDADE.jpg",
  }),
 (personagem209 = {
    nome: "HAMBÚRGUER",
    imagem: "./img/HAMBURGUE.jpg",
  }),
 (personagem210 = {
    nome: "HAMSTER",
    imagem: "./img/HAMESTER.jpg",
  }),
 (personagem211 = {
    nome: "HARPA",
    imagem: "./img/HARPA.jpg",
  }),
 (personagem212 = {
    nome: "HARRY",
    imagem: "./img/HARRY.jpg",
  }),
 (personagem213 = {
    nome: "HAVAIANAS",
    imagem: "./img/HAVAIANAS.jpg",
  }),
 (personagem214 = {
    nome: "HELICÓPTERO",
    imagem: "./img/HELICOPTERO.jpg",
  }),
 (personagem215 = {
    nome: "HELLO KITTY",
    imagem: "./img/HELLO-KITTY.jpg",
  }),
 (personagem216 = {
    nome: "HÉRCULES",
    imagem: "./img/HERCULES.jpg",
  }),
 (personagem217 = {
    nome: "HIDRANTE",
    imagem: "./img/HIDRANTE.jpg",
  }),
 (personagem218 = {
    nome: "HIENA",
    imagem: "./img/HIENA.jpg",
  }),
 (personagem219 = {
    nome: "HIGIENE",
    imagem: "./img/HIGIENE.jpg",
  }),
 (personagem220 = {
    nome: "HIPOPÓTAMO",
    imagem: "./img/HIPOPOTAMO.jpg",
  }),
 (personagem221 = {
    nome: "HOMEM-ARANHA",
    imagem: "./img/HOMEM-ARANHA.jpg",
  }),
 (personagem222 = {
    nome: "HORTA",
    imagem: "./img/HORTA.jpg",
  }),
 (personagem223 = {
    nome: "HORTELÃ",
    imagem: "./img/HORTELA.jpg",
  }),
 (personagem224 = {
    nome: "HOSPITAL",
    imagem: "./img/HOSPITAL.jpg",
  }),
 (personagem225 = {
    nome: "HOTEL",
    imagem: "./img/HOTEL.jpg",
  }),
 (personagem226 = {
    nome: "HULK",
    imagem: "./img/HULK.jpg",
  }),
 (personagem227 = {
    nome: "HUMANO",
    imagem: "./img/HUMANO.jpg",
  }),
 (personagem228 = {
    nome: "IGLU",
    imagem: "./img/IGLU.jpg",
  }),
 (personagem229 = {
    nome: "IGREJA",
    imagem: "./img/IGREJA.jpg",
  }),
 (personagem230 = {
    nome: "ILHA",
    imagem: "./img/ILHA.jpg",
  }),
 (personagem231 = {
    nome: "IMÃ",
    imagem: "./img/IMA.jpg",
  }),
 (personagem232 = {
    nome: "INCÊNDIO",
    imagem: "./img/INCENDIO.jpg",
  }),
 (personagem233 = {
    nome: "ÍNDIO",
    imagem: "./img/INDIO.jpg",
  }),
 (personagem234 = {
    nome: "INJEÇÃO",
    imagem: "./img/INJECAO.jpg",
  }),
 (personagem235 = {
    nome: "INVERNO",
    imagem: "./img/INVERNO.jpg",
  }),
 (personagem236 = {
    nome: "IOIÔ",
    imagem: "./img/IOIO.jpg",
  }),
 (personagem237 = {
    nome: "IOGURTE",
    imagem: "./img/IOGURTE.jpg",
  }),
 (personagem238 = {
    nome: "JABUTICABA",
    imagem: "./img/JABUTICABA.jpg",
  }),
 (personagem239 = {
    nome: "JACARÉ",
    imagem: "./img/JACARE.jpg",
  }),
 (personagem240 = {
    nome: "JANELA",
    imagem: "./img/JANELA.jpg",
  }),
 (personagem241 = {
    nome: "JANGADA",
    imagem: "./img/JANGADA.jpg",
  }),
 (personagem242 = {
    nome: "JANTAR",
    imagem: "./img/JANTAR.jpg",
  }),
 (personagem243 = {
    nome: "JAPÃO",
    imagem: "./img/JAPAO.jpg",
  }),
 (personagem244 = {
    nome: "JAQUETA",
    imagem: "./img/JAQUETA.jpg",
  }),
 (personagem245 = {
    nome: "JARDIM",
    imagem: "./img/JARDIM.jpg",
  }),
 (personagem246 = {
    nome: "JARDINEIRO",
    imagem: "./img/JARDINEIRO.jpg",
  }),
 (personagem247 = {
    nome: "JARRA",
    imagem: "./img/JARRA.jpg",
  }),
 (personagem248 = {
    nome: "JAVALI",
    imagem: "./img/JAVALI.jpg",
  }),
 (personagem249 = {
    nome: "JOANINHA",
    imagem: "./img/JOANINHA.jpg",
  }),
 (personagem250 = {
    nome: "JOELHO",
    imagem: "./img/JOELHO.jpg",
  }),
 (personagem251 = {
    nome: "JUDÔ",
    imagem: "./img/JUDO.jpg",
  }),
 (personagem252 = {
    nome: "JUJUBA",
    imagem: "./img/JUJUBA.jpg",
  }),
 (personagem253 = {
    nome: "JUMENTO",
    imagem: "./img/JUMENTO.jpg",
  }),
 (personagem254 = {
    nome: "JUNINA",
    imagem: "./img/JUNINA.jpg",
  }),
 (personagem255 = {
    nome: "KARATÊ",
    imagem: "./img/KARATE.jpg",
  }),
 (personagem256 = {
    nome: "KETCHUP",
    imagem: "./img/KETCHUP.jpg",
  }),
 (personagem257 = {
    nome: "KIMONO",
    imagem: "./img/KIMONO.jpg",
  }),
 (personagem258 = {
    nome: "KIWI",
    imagem: "./img/KIWI.jpg",
  }),
 (personagem259 = {
    nome: "KOALAS",
    imagem: "./img/KOALAS.jpg",
  }),
 (personagem260 = {
    nome: "KOMBI",
    imagem: "./img/KOMBI.jpg",
  }),
 (personagem261 = {
    nome: "LAGARTA",
    imagem: "./img/LAGARTA.jpg",
  }),
 (personagem262 = {
    nome: "LAGARTIXA",
    imagem: "./img/LAGARTIXA.jpg",
  }),
 (personagem263 = {
    nome: "LAGARTO",
    imagem: "./img/LAGARTO.jpg",
  }),
 (personagem264 = {
    nome: "LAGO",
    imagem: "./img/LAGO.jpg",
  }),
 (personagem265 = {
    nome: "LAGOSTA",
    imagem: "./img/LAGOSTA.jpg",
  }),
 (personagem266 = {
    nome: "LÁGRIMAS",
    imagem: "./img/LAGRIMAS.jpg",
  }),
 (personagem267 = {
    nome: "LÂMPADA",
    imagem: "./img/LAMPADA.jpg",
  }),
 (personagem268 = {
    nome: "LANCHA",
    imagem: "./img/LANCHA.jpg",
  }),
 (personagem269 = {
    nome: "LANCHE",
    imagem: "./img/LANCHE.jpg",
  }),
 (personagem270 = {
    nome: "LANTERNA",
    imagem: "./img/LANTERNA.jpg",
  }),
 (personagem271 = {
    nome: "LÁPIS",
    imagem: "./img/LAPIS.jpg",
  }),
 (personagem272 = {
    nome: "LARANJA",
    imagem: "./img/LARANJA.jpg",
  }),
 (personagem273 = {
    nome: "LAREIRA",
    imagem: "./img/LAREIRA.jpg",
  }),
 (personagem274 = {
    nome: "LASANHA",
    imagem: "./img/LASANHA.jpg",
  }),
 (personagem275 = {
    nome: "LATA",
    imagem: "./img/LATA.jpg",
  }),
 (personagem276 = {
    nome: "LAVANDERIA",
    imagem: "./img/LAVANDERIA.jpg",
  }),
 (personagem277 = {
    nome: "LEÃO",
    imagem: "./img/LEAO.jpg",
  }),
 (personagem278 = {
    nome: "LEBRE",
    imagem: "./img/LEBRE.jpg",
  }),
 (personagem279 = {
    nome: "LEGUMES",
    imagem: "./img/LEGUMES.jpg",
  }),
 (personagem280 = {
    nome: "LEITE",
    imagem: "./img/LEITE.jpg",
  }),
 (personagem281 = {
    nome: "LEITURA",
    imagem: "./img/LEITURA.jpg",
  }),
 (personagem282 = {
    nome: "LENHADOR",
    imagem: "./img/LENHADOR.jpg",
  }),
 (personagem283 = {
    nome: "LEOA",
    imagem: "./img/LEOA.jpg",
  }),
 (personagem284 = {
    nome: "LEQUE",
    imagem: "./img/LEQUE.jpg",
  }),
 (personagem285 = {
    nome: "CARAMUJO",
    imagem: "./img/CARAMUJO.jpg",
  }),
 (personagem286 = {
    nome: "LIBÉLULA",
    imagem: "./img/LEGUMES.jpg",
  }),
 (personagem287 = {
    nome: "LIMONADA",
    imagem: "./img/LIMONADA.jpg",
  }),
 (personagem288 = {
    nome: "LIQUIDIFICADOR",
    imagem: "./img/LIQUIDIFICADOR.jpg",
  }),
 (personagem289 = {
    nome: "LIVROS",
    imagem: "./img/LIVROS.jpg",
  }),
 (personagem290 = {
    nome: "LOBO",
    imagem: "./img/LOBO.jpg",
  }),
 (personagem291 = {
    nome: "LOCOMOTIVA",
    imagem: "./img/LOCOMOTIVA.jpg",
  }),
 (personagem292 = {
    nome: "LONTRA",
    imagem: "./img/LONTRA.jpg",
  }),
 (personagem293 = {
    nome: "LOUSA",
    imagem: "./img/LOUSA.jpg",
  }),
 (personagem294 = {
    nome: "LUNETA",
    imagem: "./img/LUNETA.jpg",
  }),
 (personagem279 = {
    nome: "MAÇÃ",
    imagem: "./img/LEGUMES.jpg",
  }),
 (personagem280 = {
    nome: "MACACO",
    imagem: "./img/MACACO.jpg",
  }),
 (personagem281 = {
    nome: "MALABARISTA",
    imagem: "./img/MALABARISTA.jpg",
  }),
 (personagem282 = {
    nome: "MARACUJÁ",
    imagem: "./img/MARACUJA.jpg",
  }),
 (personagem283 = {
    nome: "MEL",
    imagem: "./img/MEL.jpg",
  }),
 (personagem284 = {
    nome: "MELANCIA",
    imagem: "./img/MELANCIA.jpg",
  }),
 (personagem285 = {
    nome: "MELÃO",
    imagem: "./img/MELAO.jpg",
  }),
 (personagem286 = {
    nome: "MESA",
    imagem: "./img/MESA.jpg",
  }),
 (personagem287 = {
    nome: "MILHO",
    imagem: "./img/MILHO.jpg",
  }),
 (personagem288 = {
    nome: "MILKSHAKE",
    imagem: "./img/MILKSHAKE.jpg",
  }),
 (personagem289 = {
    nome: "MOANA",
    imagem: "./img/MOANA.jpg",
  }),
 (personagem290 = {
    nome: "MORANGO",
    imagem: "./img/MORANGO.jpg",
  }),
 (personagem291 = {
    nome: "MOTO",
    imagem: "./img/MOTO.jpg",
  }),
 (personagem292 = {
    nome: "NATAÇÃO",
    imagem: "./img/NATACAO.jpg",
  }),
 (personagem293 = {
    nome: "NAVIO",
    imagem: "./img/NAVIO.jpg",
  }),
 (personagem294 = {
    nome: "NEMO",
    imagem: "./img/NEMO.jpg",
  }),
 (personagem295 = {
    nome: "NEVE",
    imagem: "./img/NEVE.jpg",
  }),
 (personagem296 = {
    nome: "NOEL",
    imagem: "./img/NOEL.jpg",
  }),
 (personagem297 = {
    nome: "NOITE",
    imagem: "./img/NOITE.jpg",
  }),
 (personagem298 = {
    nome: "ÓCULOS",
    imagem: "./img/OCULOS.jpg",
  }),
 (personagem299 = {
    nome: "ONÇA",
    imagem: "./img/ONCA.jpg",
  }),
 (personagem300 = {
    nome: "ONDA",
    imagem: "./img/ONDA.jpg",
  }),
 (personagem301 = {
    nome: "OURO",
    imagem: "./img/OURO.jpg",
  }),
 (personagem302 = {
    nome: "OVELHA",
    imagem: "./img/OVELHA.jpg",
  }),
 (personagem303 = {
    nome: "OVOS",
    imagem: "./img/OVOS.jpg",
  }),
 (personagem304 = {
    nome: "PALHAÇO",
    imagem: "./img/PALHACO.jpg",
  }),
 (personagem305 = {
    nome: "PANDA",
    imagem: "./img/PANDA.jpg",
  }),
 (personagem306 = {
    nome: "PANDEIRO",
    imagem: "./img/PANDEIRO.jpg",
  }),
 (personagem307 = {
    nome: "PANQUECA",
    imagem: "./img/PANQUECA.jpg",
  }),
 (personagem308 = {
    nome: "PÁSSARO",
    imagem: "./img/PASSARO.jpg",
  }),
 (personagem309 = {
    nome: "PATO",
    imagem: "./img/PATO.jpg",
  }),
 (personagem310 = {
    nome: "PAVÃO",
    imagem: "./img/PAVAO.jpg",
  }),
 (personagem311 = {
    nome: "PERA",
    imagem: "./img/PERA.jpg",
  }),
 (personagem312 = {
    nome: "PERU",
    imagem: "./img/PERU.jpg",
  }),
 (personagem313 = {
    nome: "PIANO",
    imagem: "./img/PIANO.jpg",
  }),
 (personagem314 = {
    nome: "PIMENTÃO",
    imagem: "./img/PIMENTAO.jpg",
  }),
 (personagem315 = {
    nome: "PIRANHA",
    imagem: "./img/PIRANHA.jpg",
  }),
 (personagem316 = {
    nome: "PIRATA",
    imagem: "./img/PIRATA.jpg",
  }),
 (personagem317 = {
    nome: "PIZZA",
    imagem: "./img/PIZZA.jpg",
  }),
 (personagem318 = {
    nome: "POÇO",
    imagem: "./img/POCO.jpg",
  }),
 (personagem319 = {
    nome: "POMBA",
    imagem: "./img/POMBA.jpg",
  }),
 (personagem320 = {
    nome: "PORCO",
    imagem: "./img/PORCO.jpg",
  }),
 (personagem321 = {
    nome: "PUDIM",
    imagem: "./img/PUDIM.jpg",
  }),
 (personagem322 = {
    nome: "QUATI",
    imagem: "./img/QUATI.jpg",
  }),
 (personagem323 = {
    nome: "QUEIJO",
    imagem: "./img/QUEIJO.jpg",
  }),
 (personagem324 = {
    nome: "RABANETE",
    imagem: "./img/RABANETE.jpg",
  }),
 (personagem325 = {
    nome: "RAPOSA",
    imagem: "./img/RAPOSA.jpg",
  }),
 (personagem326 = {
    nome: "RAPUNZEL",
    imagem: "./img/RAPUNZEL.jpg",
  }),
 (personagem327 = {
    nome: "REI",
    imagem: "./img/REI.jpg",
  }),
 (personagem328 = {
    nome: "RELÓGIO",
    imagem: "./img/RELOGIO.jpg",
  }),
 (personagem329 = {
    nome: "RESFRIADO",
    imagem: "./img/RESFRIADO.jpg",
  }),
 (personagem330 = {
    nome: "RINOCERONTE",
    imagem: "./img/RINOCERONTE.jpg",
  }),
 (personagem331 = {
    nome: "RIO",
    imagem: "./img/RIO.jpg",
  }),
 (personagem332 = {
    nome: "ROBÔ",
    imagem: "./img/ROBO.jpg",
  }),
 (personagem333 = {
    nome: "ROSA",
    imagem: "./img/ROSA.jpg",
  }),
 (personagem334 = {
    nome: "RUBI",
    imagem: "./img/RUBI.jpg",
  }),
 (personagem335 = {
    nome: "SALAME",
    imagem: "./img/SALAME.jpg",
  }),
 (personagem336 = {
    nome: "SANDUÍCHE",
    imagem: "./img/SANDUICHE.jpg",
  }),
 (personagem337 = {
    nome: "SAPO",
    imagem: "./img/SAPO.jpg",
  }),
 (personagem338 = {
    nome: "SARDINHA",
    imagem: "./img/SARDINHA.jpg",
  }),
 (personagem339 = {
    nome: "TÊNIS",
    imagem: "./img/TENIS.jpg",
  }),
 (personagem340 = {
    nome: "TIGRE",
    imagem: "./img/TIGRE.jpg",
  }),
 (personagem341 = {
    nome: "TOMATE",
    imagem: "./img/TOMATE.jpg",
  }),
 (personagem342 = {
    nome: "TUCANO",
    imagem: "./img/TUCANO.jpg",
  }),
 (personagem343 = {
    nome: "UNICÓRNIO",
    imagem: "./img/UNICORNIO.jpg",
  }),
 (personagem344 = {
    nome: "UNIVERSO",
    imagem: "./img/UNIVERSO.jpg",
  }),
 (personagem345 = {
    nome: "URSO",
    imagem: "./img/URSO.jpg",
  }),
 (personagem346 = {
    nome: "URUBU",
    imagem: "./img/URUBU.jpg",
  }),
 (personagem347 = {
    nome: "UVA",
    imagem: "./img/UVA.jpg",
  }),
];

let nomePersonagem;
let imagemPersonagem;
let tentativas = 5;
console.log("tentativas =" + tentativas);
let resposta;
let erros = 0;
let acertos = 0;
let finalizouPartida = false;

SorteiaImagem();
function SorteiaImagem() {
  const index = parseInt(Math.random() * listPersonagens.length);

  nomePersonagem = listPersonagens[index].nome;
  imagemPersonagem = listPersonagens[index].imagem;

  console.log(nomePersonagem);
  console.log(imagemPersonagem);

  document.getElementById("imagem").style.backgroundImage =
    "url(" + imagemPersonagem + ")";

  //fesfocar a imagem
  desfocarImagem(tentativas);
}

function desfocarImagem(valoDesfoque) {
  const imagem = document.getElementById("imagem");

  switch (valoDesfoque) {
    case 5:
      imagem.style.filter = "blur(40px)";
      break;
    case 4:
      imagem.style.filter = "blur(30px)";
      break;
    case 3:
      imagem.style.filter = "blur(20px)";
      break;
    case 2:
      imagem.style.filter = "blur(17px)";
      break;
    case 1:
      imagem.style.filter = "blur(14px)";
      break;
    case 0:
      imagem.style.filter = "blur(0)";
      break;
    default:
      break;
  }
}

document.addEventListener("keydown", (e) => {
if (finalizouPartida == false) {
  if (e.key === "Enter") {
    e.preventDefault();
    resposta = document.querySelector("#resposta").value.toUpperCase();
    if (resposta.length < 3 || !resposta.trim() || resposta == undefined) {
      personalizaModal("nomeInvalido");
      document.getElementById("resposta").value = "";
    } else {
      if (tentativas > 0) {
        if (resposta == nomePersonagem) {// se entrar aqui é porque ganhou
          acertos++;
          desfocarImagem(0);
          document.querySelector(".borda-imagem").style.border = "none";
          mudaStatusInput(true);
          finalizouPartida = true;
          personalizaModal("vitoria");
          habilitaBotaoJogarNovamente();
        } else { // se entrar aqui é porque ainda esta tentando acertar
          tentativas--;
          desfocarImagem(tentativas);
          barraDeProgresso(tentativas)
          document.getElementById("resposta").value = "";
          console.log("tentativas =" + tentativas);
        }
      }

      if (tentativas == 0) { // se entrar aqui é porque perdeu
        erros++;
        document.querySelector(".borda-imagem").style.border = "none";
        document.getElementById("resposta").value = nomePersonagem;
        mudaStatusInput(true);
        finalizouPartida = true;
        personalizaModal("derrota");
        habilitaBotaoJogarNovamente();
      }
      }
      console.log("tentativas =" + tentativas);
      document.querySelector("#derrotas").innerText = erros;
      document.querySelector("#vitorias").innerText = acertos;
    }
  }
  else{
    return;
  }
});

const modal = document.getElementById("modal-alerta");
const span = document.getElementsByClassName("close")[0];
span.onclick = function () {
  modal.style.display = "none";
};

window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};

function personalizaModal(alerta) {
  const modalMensagem = document.getElementById("modal-mensagem");

  switch (alerta) {
    case "nomeInvalido":
      modalMensagem.innerHTML = "<p> Está querendo me enganar ? </p><p>Digite um nome Válido.</p>";
      break;
    case "vitoria":
      modalMensagem.innerHTML = "<p> Você é bom nisso mesmo hein!</p><p>Nunca duvidei de você.</p>";
      break;
    case "derrota":
      modalMensagem.innerHTML = "<p> Não foi dessa vez</p><p>Aposto que voce consegue na próxima.</p>";
      break;
    default:
      break;
  }
  modal.style.display = "block";
}

function barraDeProgresso(carregaBarra) {
  if (carregaBarra == 5) {
    document.getElementById("progresso-01").style.backgroundColor = "transparent";
    document.getElementById("progresso-02").style.backgroundColor = "transparent";
    document.getElementById("progresso-03").style.backgroundColor = "transparent";
    document.getElementById("progresso-04").style.backgroundColor = "transparent";
    document.getElementById("progresso-05").style.backgroundColor = "transparent";
  } else {
    switch (carregaBarra) {
      case 4:
        document.getElementById("progresso-01").style.backgroundColor = "#ffd700";
        break;
      case 3:
        document.getElementById("progresso-02").style.backgroundColor = "#ffd700";
        break;
      case 2:
        document.getElementById("progresso-03").style.backgroundColor = "#ffd700";
        break;
      case 1:
        document.getElementById("progresso-04").style.backgroundColor = "#ffd700";
        break;
      case 0:
        document.getElementById("progresso-05").style.backgroundColor = "#ffd700";
        break;
      default:
        break;
    }
  }
}

function habilitaBotaoJogarNovamente(){
  document.getElementById("btnJogarNovamente").style.display = "inline";
}

document.querySelector("#btnJogarNovamente").addEventListener("click", function(){
  finalizouPartida = false;
  tentativas = 5;
  SorteiaImagem();
  desfocarImagem(tentativas);
  mudaStatusInput(false);
  document.getElementById("resposta").value = "";
  document.getElementById("resposta").focus();
  barraDeProgresso(5)
  document.querySelector("#btnJogarNovamente").style.display = "none";
  document.querySelector(".borda-imagem").style.border = "10px solid #00ffdd"
});

function mudaStatusInput(condicao){
  document.getElementById("resposta").disabled = condicao;
}
